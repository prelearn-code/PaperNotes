IoT Audit / ARC-Audit - Overleaf source package
打包日期：2026-10-30；主稿版本：2026-10-09（当前仓库主稿）。

导入：Overleaf -> New Project -> Upload Project，选择本 ZIP。
英文稿：Main document = main.tex；Compiler = pdfLaTeX。
中文稿：Main document = main_cn.tex；Compiler = XeLaTeX。
补充材料：Main document = supplementary.tex；Compiler = pdfLaTeX。
latexmkrc 会先编译补充材料，为主稿提供跨文档引用。

根目录直接放置主文件，无需移动目录。保留所有子目录结构。
包含：中英文正文、补充材料、BibTeX 文献库、IEEE 类与参考文献样式、
正文及补充材料使用的图片和表格源码、相关图片的 PNG/SVG/TikZ/JSON 文件。
不包含：实验程序、实验数据、文献 PDF、研究计划、编译产物。
图片目录中的 PDF 是论文插图，不是整篇论文 PDF。

兼容性调整仅限打包副本：中文稿将本机 Windows 字体路径改为
TeX Live 的 TeX Gyre Termes / Fandol 字体；字形和分页可能略有变化。
latexmkrc 不再固定主稿的编译器模式，以兼容中文稿 XeLaTeX。
后续实验尚未合入当前主稿，本包保持当前论文内容。

打包检查：英文稿 pdfLaTeX、中文稿 XeLaTeX、补充材料 pdfLaTeX
已在本地 TeX Live 中实际编译成功；全部图片、表格及文献依赖已检查。
