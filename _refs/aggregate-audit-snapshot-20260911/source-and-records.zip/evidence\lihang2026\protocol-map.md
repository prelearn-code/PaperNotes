# Li Hang 2026 协议映射

原文：*Lightweight Integrity Auditing for IoT Cloud Data Based on Lattice Hash and Smart Contract*，ICAIDE 2026。本地 PDF 为 **5 页**；未在 PDF 中找到 DOI，因此不填写 DOI。

页码一律使用 **PDF 页序**（第 1–5 页）。早期一份核验记录写成"第 81/82/83 页"，与本 PDF 不符，已按实际页序更正。

## 阶段映射

| 阶段 | 原文位置 | 实现接口 | 核验重点 |
|---|---|---|---|
| 系统模型与实体定义 | PDF 2，§III.A–B | — | 四类参与者；CS 的诚实执行假设（见下） |
| 初始化 | PDF 2，§III.C.1 | `initialization()` | `Para={q,G,G_T,g,e,H}`；`C={c_1..c_n}`；`r∈Z_q`；`Tag=(g^r, g^{rH(c_1)}, …, g^{rH(c_n)})` |
| 分发与本地删除 | PDF 2，§III.C.1 | — | 密文给 CS，**标签给审计者**；CS 不存标签、无解密密钥；车辆删除本地密文与标签，只留 `SK` |
| 挑战 | PDF 3，§III.C.2 | `challenge()` | `Q` 为 `c` 个不同下标；32 字节 nonce；`chal=(fileID,Q,nonce,timestamp,AuditorSig)` |
| 证明生成 | PDF 3，§III.C.3 | `proof_from_blocks()`、`proof_from_digests()` | `H_agg=Σ_{i∈Q}H(c_i)`；CS 自选 `s∈Z_q`；`proof=(g^s,g^{sH_agg},Q,timestamp_response,CSSig)` |
| 验证与上链 | PDF 3，§III.C.4 | `verify()` | `e(g^s, Π_{i∈Q}g^{rH(c_i)}) = e(g^r, g^{sH_agg})`，即 Eq. (1) |
| 智能合约存证 | PDF 3，§III.D | —（未实现） | 审计者签名后写入合约；本工作区不建模链上执行 |
| 用户查询与独立复核 | PDF 4，§III.E | — | 查询历史审计；"独立复核"路径与 §III.C.1 的本地删除相矛盾（见下） |
| 安全分析 | PDF 4，§IV.A | `PROFILES` | 正确性、防重放、可问责三项均为定性论证，无形式化证明 |
| 实验设置 | PDF 4–5，§IV.B | 运行器参数 | 单块 128 KB；块数 100–1000；挑战数 `c=300`；未给出 `q` 的位数 |

## 关键公式

标签（PDF 2）：

```
Tag = ( g^r, g^{r·H(c_1)}, …, g^{r·H(c_n)} )
```

证明（PDF 3）：

```
H_agg = Σ_{i∈Q} H(c_i),   proof = ( g^s, g^{s·H_agg}, Q, timestamp_response, CSSig )
```

验证（PDF 3，Eq. (1)）：

```
e(g^s, g^{r·H(C)}) = e(g^r, g^{s·H_agg})
```

其中 `g^{r·H(C)}` 由审计者持有的挑战块标签相乘得到。由于双线性，该等式等价于

```
H_agg ≡ Σ_{i∈Q} H(c_i)  (mod q)
```

因此服务器只需要"被挑战块的逐块摘要之和"，而这可以由**预存的逐块摘要**在任意新挑战下重新计算。

## 服务器诚实执行假设（决定模型裁决）

PDF 2，§III.B：

> Cloud Server (CS): Responsible for storing the data uploaded by the vehicle. CS may cause data damage or loss due to software errors, hardware failures or malicious attacks, **but will honestly execute the challenge-response protocol during the audit process.**

解析文本 L91。原文 §I 的动机又声称云可能"因经济利益"删除数据（L61）。因此**动机与形式假设不一致**：协议没有、也不可能刻画"删除数据后伪造证明"的服务器。缓存摘要策略恰好落在这一缺口内，属"主张超出模型"，不能与 Song、OTGPDP 并列为原模型内攻击。

## 原文规格缺口（不得替原文补齐）

1. **`s` 无 `≠0` 要求。** PDF 3 只写 `s∈Z_q`，验证式也不拒绝单位元。取 `s=0` 则 `(g^s, g^{sH_agg})=(1,1)`，对**任意文件**（含已损坏文件）恒过验证，且不需要任何保留状态。恶意服务器选 `s=0` 同样超出诚实执行假设；诚实均匀抽样命中零的概率为 `1/q`。
2. **nonce 未绑定证明。** nonce 只在挑战中；proof 不含 nonce，验证式也不使用它。但 PDF 4 §IV.A 声称"proof 绑定该挑战、旧证明因随机数不同而无法通过"。该论证与协议公式不一致。指数集合相同时，旧证明可被重放。
3. **`fileID` 未参与验证。** 标签与验证式都不含 `fileID`；内容相同的两个文件可互相顶替，`chal` 中的 `fileID` 实际不起绑定作用。
4. **证明中的 `Q` 是否被强制比对未规定。** 验证式需要"挑战下标集对应的标签"。原文未明确写入"必须比较 proof 的 `Q` 与本次 challenge 的 `Q`"。若实现改为读取 proof 自带的 `Q`，则服务器只保存**一个**块摘要即可通过（本项目以 `trust_proof_indexset` 开关单列该读法，不计入主结论）。
5. **只有和绑定，没有位置绑定。** 挑战集内的块互换不改变 `H_agg`。
6. **§III.E 的独立复核不可执行。** PDF 2 说车辆删除密文与标签且不保留 `r`，PDF 4 却要求车辆"重算全部块标签"。可问责链条实际完全依赖审计端。
7. **`H` 构造未规定。** 原文只说参考 LtHash 并"使用其在整数加法群上的同态性"，未给出分块方式、输出域或抗碰撞归约。
8. **签名、时间戳窗口、`q` 位数均未规定。**

## 实现模型与接口边界

- L2 使用真实超奇异曲线 `y²=x³+x`、**阶为素数 `q=2^31−1` 的子群**与嵌入次数 2 的对称约化 Tate 配对；群元素只序列化为仿射坐标，不携带离散对数。
- 三角不等式：`proof_from_digests()` 只接受逐块摘要，接口上不存在密文块参数。
- `literal` 配置完全按原文；`hardened` 是**显式加固变体**（要求 `g^s≠1`、proof 绑定 nonce 与下标集、验证双方签名），用于区分"标准修补能修什么"。
- 数据块直接作为密文字节输入，未臆测 AES 模式；`H` 采用分块可加构造（`H(m)=Σ F(chunk) mod q`），并另设**非可加**的 `plain` 哈希对照，以检查结论是否依赖格哈希的同态性。
- 参数为缩减功能参数，不提供生产安全强度；也未实现智能合约与链上存证。
- 已知限制：缩减参数下 `q` 只有 31 位，摘要的抗碰撞强度不是本研究要模拟的安全目标；缓存策略本身不需要构造任何碰撞。
