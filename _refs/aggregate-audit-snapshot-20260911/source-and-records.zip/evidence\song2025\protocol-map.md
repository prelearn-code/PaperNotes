# Song 2025 协议映射

原文：*Enabling Verifiable Search and Integrity Auditing in Encrypted Decentralized Storage Using One Proof*，DOI `10.1109/TC.2025.3569182`。

## 八算法映射

| 算法 | 原文位置 | 实现接口 | 核验重点 |
|---|---|---|---|
| Setup | PDF 5，刊物 2735，§III-B.1 | `setup()` | 生成复合阶配对参数 `(p,q,N,G1,G2,e)`，发布 `N,g,μ` 及 H1/H2/H3/π。 |
| KeyGen | PDF 5，2735，§III-B.2 | `keygen()` | `sk∈Z_N`，对称密钥 `mk,ek`，`pk=g^sk`。 |
| Insert | PDF 5--6，2735--2736，§III-B.3 | `insert()` | 密文块分成 s 个 sector；Eq. (2) 认证标签；Eq. (3)(4) 关键词标签及状态链。 |
| Delete | PDF 6，2736，§III-B.4 | `delete()` | 删除 C/TS，令每个关键词标签除以 `del=H2(ID_F)^sk`，状态标 invalid。 |
| Search | PDF 6，2736，§III-B.5 | `search_request()`、两个 search 函数 | `T,st_d` 驱动指针链；valid 文件进入 Res，全部链项的修正关键词标签进入 Eq. (6)。 |
| Proof | PDF 6，2736，§III-B.6 | 两个 proof 函数 | 未搜索文件按 Eq. (7) 产生 `(ψ,φ)`。 |
| Verify.Search | PDF 7，2737，§III-B.7 | `verify_search()` | 外部输入绑定 `T,SS(w)`；Eq. (8) 聚合，Eq. (9) 一次配对等式同时验证搜索结果与搜索文件完整性。 |
| Verify.Audit | PDF 7，2737，§III-B.7 | `verify_audit()` | 外部输入绑定 `ID_F`；未搜索文件按 Eq. (10) 验证。 |

## 数据依赖

Eq. (2)：

`σ_i=[H2(ID_F||i)·∏_{j=1}^s μ^{c_{i,j}}]^sk`。

Eq. (5)、(7)：

`ψ=Σ_i π(θ||ID_F,i)·Σ_j c_{i,j}`，`φ=∏_i σ_i^{π(θ||ID_F,i)}`。

因此证明者对每块只需要 `z_i=Σ_j c_{i,j} mod N` 和原标签。搜索证明还需要索引状态链、修正后的关键词标签和请求公开的 `(T,st_d)`；不需要 `mk`、`ek`、`sk` 或 ciphertext sectors。

## 实现模型和接口边界

- L1 的 `G1` 保存相对于生成元的指数，用作公式排错。
- L2 使用真实超奇异曲线点、复合阶子群 `N=pq` 和约化 Tate 配对；群元素只序列化为规范仿射坐标，不保存指数。
- L2 的 p、q、基域素数和目标群完整阶经过独立测试；所有 Eq. (2)--(10) 按 `Z_N` 执行。
- 输入直接是 ciphertext sector 域元素，避免臆测 AES 模式与字节编码。
- 指针使用 H3 派生的可逆异或编码，只建模论文要求的状态链语义。
- 攻击状态不含 `states`、`mk`、`ek`、`sk` 或 `sectors`。每次搜索请求单独提供公开的 `T` 和 `st_d`。

最终 `l2-final-20260911` 属于真实群运算/配对的 L2 依论文重实现。参数为缩减功能参数，并非生产安全参数；哈希到曲线与曲线选型也是明确实现选择，不声称与作者 PBC 原型二进制兼容。指数 L1 模型不再作为最终攻击证据。

## 测试限定

- `s=1` 是控制组，投影等于原 sector。
- `s>1` 时可构造多组 sector 向量具有相同块和，但完整保留状态还有 `ID_F=H(C)`；所以不能仅由秩不足推出整个状态的信息论不可区分。
- 攻击结论是：在 L2 真实配对模型中，保留投影和标签可生成任意新挑战的两类合法证明。
- 真实下载仍缺少 C，无法重新计算 `H(C)`；审计接受与下载成功必须分别报告。
- 删除后的 invalid 链项仍参与 Eq. (6)，但 `H2(ID_F)^sk` 已从关键词标签中除去；测试覆盖这一状态转换。

## 原文未规定的实现细节

- AES-256 的模式、nonce、padding 和 sector 编码。
- H2 的具体哈希到复合阶群算法和群元素序列化。
- π 的具体构造、挑战是否有放回及链上种子的生命周期。
- 实验中 s 的明确取值在已核页中未给出。
