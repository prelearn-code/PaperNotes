# 聚合审计信息损失：简单复现工作区

当前状态：三篇逐式映射、协议重实现、隔离攻击者、负面对照和实验运行器已实现。OTGPDP 使用真实模幂群；Song 已完成真实复合阶曲线子群和 Tate 配对的缩减参数 L2 复现；Li Hang 已完成真实**素数阶 type-1 配对**的缩减参数 L2 复现。结论以 `REPORT.md` 和实际 `results/` 为准。

执行入口：[贡献二自主验证任务安排](TASKS.md)。来源与 SHA-256：[原文清单](evidence/source-manifest.json)。本阶段优先 Song 与 OTGPDP，Li Hang 作为方法案例补充（其形式模型不允许恶意服务器，见 `REPORT.md`）。

## 范围

后续在本目录验证：服务器只保留固定投影、块哈希或公开标签时，是否仍能通过新挑战；以及保留状态是否足以提取原始数据。

正式研究依据见 [创新性核验报告](../../../01_Literature/Notes/Audit-and-Integrity/完整性审计三条主线与备选_创新性核验_2026-09-10.md)。论文解析位于 `../../literature/2025/`、`../../literature/2026/`。

## 目录约定

| 目录 | 用途 |
|---|---|
| `scripts/` | 各案例模型、诚实与作弊应答、恢复过程；文件以 `song2025_`、`otgpdp2025_`、`lihang2026_` 等前缀区分 || `tests/` | 诚实正确性、攻击成功条件、恢复测试及安全基线对照 |
| `results/<案例>/<运行标识>/` | 参数、随机种子、依赖版本、运行命令、日志和结构化结果；每次运行新建目录 |
| `certificates/` | 由 `scripts/analysis_certificate.py` 生成的可复核证书；计数必须与 `results/` 一致 |
| `evidence/` | 原文页、公式截图和核验说明，不混入实验输出 |

## 运行

```powershell
python -m unittest discover -s tests -v
python scripts/run_experiments.py --instances 10 --challenges 100 --run-id <新运行标识>
python scripts/run_song_l2_experiments.py --instances 10 --challenges 100 --run-id <新 L2 运行标识>
python scripts/run_lihang2026_experiments.py --instances 10 --challenges 100 --blocks 32 --challenge-size 8 --run-id <新 Li Hang 运行标识>
python scripts/run_zhang2025_experiments.py --instances 10 --challenges 100 --challenge-size 6 --run-id <新 Zhang 运行标识>
python scripts/run_baseline_experiments.py --instances 10 --run-id <新基线标识>
python scripts/run_high_security_experiments.py --instances 3 --bits 256 --run-id <新大参数标识>
python scripts/run_state_accounting.py --blocks 64 --sectors 8 --run-id <新状态核算标识>
python scripts/run_yang2026_experiments.py --instances 10 --challenges 100 --run-id <新负面对照标识>
python scripts/run_miao2025_experiments.py --instances 10 --challenges 100 --run-id <新第二负面对照标识>
python -m scripts.analysis_certificate --output certificates/aggregate-audit-certificates.json
python -m scripts.independent_verifier --output certificates/independent-recheck.json
```

`run_baseline_experiments.py` 运行的是**正面对照**（认证可提取基线），不是候选方案：它检验分析框架能否区分"每 sector 独立生成元"与"所有 sector 共用底数"两种结构。`analysis_certificate.py` 为四个案例生成可复核证书，并强制证书中的计数与所引用运行的 `summary.json` 一致。`independent_verifier.py` 是**独立第二读法**：不导入案例协议模块，直接从论文公式重写校验并回放已记录的响应。

隔离证明者由实验运行器通过新 Python 进程调用。每个案例的参数、环境、源码指纹、攻击状态、请求、响应、日志和结构化结果保存在对应运行目录。

四套运行器现在采用同一套严格约定：实验数据（Song 另加客户端密钥）由**未写入运行目录**的秘密生成、只记录承诺；攻击状态在**生成挑战之前**先落盘；每个挑战独立。这三条回应了早前"公开种子使数据可重建、挑战提前可见"的批评。更早的运行记录（`*-20260910`、`l2-final-20260911`）不具备这些性质。

## 已有证据

`evidence/song2025/` 的三张 PNG 来源于正式论文 PDF（位于工作区 `01_Literature/PDF/2025/`）：

- `song2025-equations-page6.png`：PDF 第 6 页，对应刊物页码 2736，包含 Eq. (2)、(5)、(7)。
- `song2025-equations-page7.png`：PDF 第 7 页，供验证算法与相邻论证核对。
- `song2025-equation2-crop.png`：第 6 页 Eq. (2) 区域放大裁图，用于区别底数与指数下标。

这些是原文核验材料，不是运行结果。整页视觉识别曾误读下标，放大复核与原生 PDF 文本提取一致；不能用单次 OCR 结果代替完整协议检查。

OTGPDP 的正式 PDF 位于 [evidence/otgpdp2025/OTGPDP-2025-official.pdf](evidence/otgpdp2025/OTGPDP-2025-official.pdf)，从出版方下载并核验为 16 页，DOI 为 `10.32604/cmc.2025.059949`。同目录的 `publisher-download.html` 是下载入口快照，不是 PDF 正文。

## 候选案例及状态

| 案例 | 拟验证内容 | 不能省略的条件 | 状态 |
|---|---|---|---|
| Song 2025 | 保存每块 sector 和是否足够应答 | sector 数量、取值范围、编码约束、全套验证算法 | 缩减参数真实配对 L2 已完成（含删除后统一搜索、已搜索／未搜索混合周期） |
| OTGPDP 2025 | 是否可仅由公开标签生成合法响应 | 原协议初始化、CBF、证明格式和原始数据提取目标 | 修正配置 L2 已完成（含更新语义与重签负面对照）；**逐字配置的 CBF 初值未定义**：初值 0 时诚实失败、初值 1 时标签攻击成立 |
| Li Hang 2026 | 保存逐块摘要是否足够应答 | 原文公式、诚实执行假设、模型边界 | 缩减参数素数阶配对 L2 已完成；结论是**模型错位**而非原模型内攻击 |
| Yang 2026 | **负面对照**：正确方案是否会被误报 | 判据须按键在"投影是否对服务器可计算" | 关键审计路径已完成；published 配置下缓存投影策略 0/1000（不误报），公开系数对照 1000/1000 |
| Miao 2025 | **第二负面对照**（IEEE TDSC） | 同上 | 关键审计路径已完成；结果与 Yang 一致（0/1000 与 1000/1000） |
| Zhang 2025 | 保存逐块哈希与 sector 和是否足够应答 | 验证式是否绑定挑战与逐 sector 方向 | 缩减参数素数阶配对 L2 已完成；**原模型内失败实例**（含单块 O(1) 状态与跨挑战复用） |

案例与原文的对应见各自 `evidence/<案例>/protocol-map.md`。Li Hang 的协议映射在 `evidence/lihang2026/protocol-map.md`。

## 证据链（每个结论可逐项追溯）

| 案例 | 原文定位 | 运行记录 | 证书 `model_status` | 复跑入口 |
|---|---|---|---|---|
| Song 2025 | `evidence/song2025/protocol-map.md`；Definition 5 在 PDF 第 4 页 | `results/song2025/l2-strict-20260911/`（另附 `extractability-argument.md`） | `in-model` | `run_song_l2_experiments.py` |
| OTGPDP 2025 | `evidence/otgpdp2025/protocol-map.md` | `results/otgpdp2025/strict-20260911/`（含更新语义与重签对照） | `explicit-variant` | `run_experiments.py` |
| Li Hang 2026 | `evidence/lihang2026/protocol-map.md`（诚实执行假设在 PDF 第 2 页） | `results/lihang2026/l2-final-20260911/` | `model-mismatch` | `run_lihang2026_experiments.py` |
| Zhang 2025 | `evidence/zhang2025/protocol-map.md`（威胁模型在 PDF 第 4 页，Eq. 7/8 在第 7 页） | `results/zhang2025/l2-final-20260911/` | `in-model` | `run_zhang2025_experiments.py` |
| Yang 2026（负面对照） | `evidence/yang2026/protocol-map.md`（对抗者 A3 在 PDF 第 5 页） | `results/yang2026/neg-final-20260911/` | `in-model`（作为正确方案） | `run_yang2026_experiments.py` |
| Miao 2025（第二负面对照） | `results/miao2025/neg-final-20260911/analysis.md` | `results/miao2025/neg-final-20260911/` | `in-model`（作为正确方案） | `run_miao2025_experiments.py` |
| 认证基线（正面对照） | 本目录测试矩阵 | `results/baseline/baseline-final-20260911/` | `in-model` | `run_baseline_experiments.py` |

证书由 `python -m scripts.analysis_certificate` 生成，校验时会强制"证书计数＝运行记录计数"，因此引用无法悄悄过期。

## 实验记录要求

- 第一步可用小有限域做代数一致性验证，但须明确标为玩具模型，不能当作原密码系统的安全实验。
- 给出诚实执行对照，再比较仅保留摘要/标签的作弊者；统计包括标签、索引和辅助信息的总状态。
- 输出审计接受率与原数据恢复结果，不能只报告验算等式成立。
- 固定种子和参数，保留失败案例；明确挑战是否独立、是否有放回以及是否允许服务器拒答。
- 简单复现的脚本、测试及结果均留在本目录，不改写 `literature/` 内原始解析，不运行 Zotero 归档脚本。
