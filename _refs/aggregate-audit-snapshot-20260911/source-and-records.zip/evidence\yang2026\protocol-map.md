# Yang 2026 协议映射（负面对照）

原文：*Shared Data Integrity Audit Scheme Based on CP-ABE and Deduplication for Cloud Storage*，Xiaodong Yang 等，**IEEE Transactions on Network and Service Management, 2026**，DOI `10.1109/TNSM.2025.3650222`。本地 PDF 15 页。

**本案例的用途是贡献一的负面对照**：它是真实已发表、显式允许恶意 CSP 伪造证明的方案，且其审计路径对"只保留块和"的缓存策略**免疫**。因此用于验证判据不会误报。本工作区**没有**对其做出任何攻击声明。

## 阶段映射（PDF 页序）

| 阶段 | 位置 | 实现接口 | 核验重点 |
|---|---|---|---|
| 系统模型与对抗者 | PDF 5 | — | **A3："A malicious CSP that attempts to falsify proof to deceive a DA and pass integrity verification"** |
| Setup / KeyGen | PDF 6 | `setup()`、`keygen()` | `MSK=s`、`MPK=g^s`；`K_dos=H1(id_DO)^s`；`α_DO` 私有、`K_dp=g^{α_DO}` |
| TagGen | PDF 7 | `taggen()` | 选择 `s` 个 `{a_j}`，公布 `A_j=g^{a_j}`；`SK_F=H3(k_l)`；`η=H3(k_l‖kc_i)`；Eq. (1) |
| ChalGen | PDF 7 | `challenge()` | `chal=(c,k_1,k_2)`；`f_i=prp(k_1,i)`、`v_i=prf(k_2,i)` |
| ProofGen | PDF 7 | `proof_from_data()` | Eq. (7)：逐 sector 聚合 `μ_j=Σ_i v_i c_{f_i j}` |
| ProofVerify | PDF 7 | `verify_audit()` | Eq. (8)：`e(σ,g)=e(H1(id_DO)^{Σv_i},MPK)·e(Π_i H4(η‖SK_F‖i)^{v_i}·Π_j A_j^{u_j},K_dp)` |
| 安全性论证 | PDF 9 | — | Theorem 4（DL 归约，对抗 A3）；原文自行论证伪造需 `Σ_j a_j(u_j−u'_j)=0`，而 `(a_1,…,a_s)` **对 CSP 未知** |

## 关键公式

标签（Eq. 1，PDF 7）：

```
σ_i = K_dos · ( H4(η‖SK_F‖i) · g^{ Σ_{j=1}^{s} a_j c_{i,j} } )^{ α_DO }
```

证明（Eq. 7，PDF 7）：

```
σ = Π_{i=1}^{c} σ_{f_i}^{ v_i }
μ_j = Σ_{i=1}^{c} v_i · c_{f_i j}          (1 ≤ j ≤ s)
```

验证（Eq. 8，PDF 7）：

```
e(σ, g) = e( H1(id_DO)^{Σ v_i}, MPK ) · e( Π_i H4(η‖SK_F‖i)^{v_i} · Π_{j=1}^{s} A_j^{u_j}, K_dp )
```

其中 `u_j` 是服务器返回的逐 sector 聚合（原文在 ProofGen 写 `μ_j`、在验证写 `u_j`，命名不一致但语义相同）。

## 为什么它对该缓存策略免疫（也是判据的关键）

数据只经**一个标量投影** `z'_i = Σ_j a_j c_{i,j}` 进入标签——形式上与 Song/Zhang 的固定投影同类。但：

- 服务器只看到 `A_j = g^{a_j}` 与标签 `σ_i`，**无法计算 `z'_i`**，因为 `a_j` 对它是秘密的；
- 它也无法从 `{σ_i}` 反推：`σ_i = K_dos·(H4_i·g^{z'_i})^{α_DO}`，而 `α_DO`、`K_dos` 均不在其掌握；
- 若它只保留每块 sector 和 `z_i = Σ_j c_{i,j}` 与标签，则在验证式里它必须给出 `u_j` 使 `Π_j A_j^{u_j} = g^{Σ_j a_j μ_j}`；它知道 `Σ_j μ_j` 却不知道 `Σ_j a_j μ_j`，求表示需要 `a_j`。

原文第 322 行自己给出的正是这一论证：伪造需 `Σ_j a_j(u_j − u'_j) = 0`，而 `(a_1,…,a_s)` 对 CSP 未知，概率 `≤ 1/q`。

**因此判据不能写成"存在固定投影即失效"，必须检查投影系数是否对服务器可计算。** 本工作区为此加了显式的敏感性对照：把同一构造的 `a_j` 公开（仅作为对照变体，不针对原文），攻击随即成立——见 `tests/test_yang2026.py` 与 `results/yang2026/`。

## 实现边界

- 只实现**关键审计路径**（Setup、KeyGen、TagGen、ProofGen、ProofVerify），不复现 CP-ABE、去重、PoW 与链上部分。
- 使用与 Li Hang/Zhang 相同的素数阶 type-1 缩减参数后端；本案例用于**判据的负面对照**，不用于安全强度结论。
- 原文未规定 `π`/`prf`/`prp`/`H4` 的具体构造，本实现使用域分离 PRF 与哈希到群，属明确实现选择。
- 公开系数变体是本工作区为检验判据而构造的**对照**，不是对原文的修改建议或攻击声明。
