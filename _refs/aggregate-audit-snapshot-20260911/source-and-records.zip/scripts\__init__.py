"""Independent reproductions for the aggregate-audit study."""
