# OTGPDP 2025 协议映射

原文：*Provable Data Possession with Outsourced Tag Generation for AI-Driven E-Commerce*，DOI `10.32604/cmc.2025.059949`。页码以下同时给出 PDF 页序和刊物页码。

## 八算法映射

| 算法 | 原文位置 | 输入/输出与实现接口 | 核验结果 |
|---|---|---|---|
| Setup | PDF 6，刊物 2724，§4.2.1 | `(λ)->(SK,PK)`；`setup()` | 群阶记为素数 `p`；客户端与云各有签名密钥。签名算法未规定。 |
| DataProcess | PDF 6，2724，§4.2.2 | `D* -> D`；`data_process()` | 分块后可加 `PN(seed1)` 掩码，`d_i=d_i*+rn_i`；也允许不保护或改用对称加密。 |
| MetaGen | PDF 6--7，2724--2725，§4.2.3 | `(D,X)->(Tag,CBF)`；`meta_gen()` | `t_i=H(filename||i)·g^{d_i}`，CBF 对标签 `t_i` 的 k 个哈希位置加一。 |
| MetaVer | PDF 7，2725，§4.2.4 | `(CBF,D)->bool`；`meta_verify()` | 客户端抽样重算标签。原文明确要求所有位置“大于 1”。 |
| Challenge | PDF 7，2725，§4.2.5 | `()->(chal,chal_sig)`；`challenge()` | `chal=(c,sd2,sd3)`；`sd2` 选索引，`sd3` 生成系数；客户端签名。 |
| Proof | PDF 7，2725，§4.2.6 | `(chal,chal_sig)->(P,P_sig,Tag^c)`；两个 proof 函数 | `P=g^{Σa_i·m_i}`，返回挑战标签及云签名。此处使用 `m_i`，与此前 `d_i` 不一致。 |
| Verify | PDF 7--8，2725--2726，§4.2.7 | `(chal,P,P_sig,Tag^c)->bool`；`verify()` | 先查 CBF，再令 `δ=∏t_i^{a_i}`，验证 `δ=∏H(filename||i)^{a_i}·P`。正文没有写挑战签名或响应签名的验证步骤。 |
| DataUp | PDF 8，2726，§4.2.8 | `(op)->CBF_update`；`update()` | ADD/DEL/MOD 都把 `d_update` 的哈希位置加一；与 CBF 原本存标签不一致，DEL 也未减计数。 |

## 安全定义和攻击接口

- PDF 5，2723，Definition 2：诚实双方应使 CBF 通过 MetaVer、证明通过 Verify。
- Definition 3 的文字把“损坏后仍能构造证明的概率可忽略”称为 unforgeability。
- Definition 4 要求少量损坏以不可忽略概率被发现。
- PDF 8--9 的 Theorem 2 假设攻击者需要伪造新标签或碰撞 CBF，没有讨论保留原标签。

标签保留状态为：`filename`、全部原标签、公开参数、云自己的合法签名私钥。客户端签名私钥、数据块、掩码种子均不保留。新挑战到达后：

`P = ∏(t_i / H(filename||i))^{a_i}`。

这与诚实 `g^{Σa_i d_i}` 相等。攻击不修改 CBF、不伪造标签，云可用自己的合法密钥签新响应。

## 三个实现配置

原文逐字文本为：MetaGen *"increments the value by one at the corresponding positions"*（PDF 7，刊物 2725），MetaVer 要求 *"the values at the k hash positions of each tsi in the CBF are greater than 1"*（PDF 7，刊物 2725）。**原文从未规定计数器初值**，而初值决定了 ">1" 是否可满足，因此把两种约定都显式实现：

`literal`
    计数器初值 **0**（Bloom 过滤器的常规约定），阈值 `>1`，不检查签名，DataUp 对数据值哈希且所有操作加一。此时无碰撞标签的计数为 1，诚实 MetaVer **必然失败**。

`literal_initialized`
    计数器初值 **1**，其余同 `literal`。此时 ">1" 等价于"至少插入过一次"，逐字流程**可执行**——而**标签保留攻击在同一配置下同样成立**。

`corrected`
    显式修正变体：初值 0、成员阈值改为 1、验证两端签名、更新时对旧标签减一、对新标签加一。每项都是显式修正，不冒称原文规定。

**结论因此收窄为"初值未定义"，而不是确定的"原文不可执行"：** 初值取 0 时逐字流程诚实失败；初值取 1 时逐字流程可执行且可被标签保留策略通过。两种读法下都存在问题，但问题性质不同（前者是规格不足，后者是验证不足）。

## 未规定或不一致之处

- 群实例、安全参数、群元素编码、哈希到群方法未规定。
- 签名算法及签名消息编码未规定。
- Proof 的 `m_i` 与 DataProcess/MetaGen 的 `d_i` 不一致。
- Verify 列表中的执行角色混写为云服务器和区块链节点。
- CBF ">1" 与"每次插入加一"在初值 0 下冲突；初值未定义，故逐字流程的可执行性取决于未声明的约定。DataUp 哈希对象和删除计数也与诚实语义冲突。
- CBF 大小公式复用了 `p`，与群阶/假阳性概率符号冲突。
- 更新没有完整说明索引重编号、旧标签替换和挑战域变化。

